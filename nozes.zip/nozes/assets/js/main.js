(function () {
	'use strict';

	// Menu mobile
	var burger = document.getElementById('nz-burger');
	var nav = document.getElementById('menu-principal');

	if (burger && nav) {
		burger.addEventListener('click', function () {
			var isOpen = nav.classList.toggle('is-open');
			burger.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
		});

		nav.querySelectorAll('a').forEach(function (link) {
			link.addEventListener('click', function () {
				nav.classList.remove('is-open');
				burger.setAttribute('aria-expanded', 'false');
			});
		});
	}

	// "Mostrar senha" no login da Área do Cliente
	document.querySelectorAll('[data-nz-toggle-password]').forEach(function (checkbox) {
		var target = document.getElementById(checkbox.getAttribute('data-nz-toggle-password'));
		if (!target) {
			return;
		}
		checkbox.addEventListener('change', function () {
			target.type = checkbox.checked ? 'text' : 'password';
		});
	});

	// Acordeão de relatórios na Área do Cliente
	document.querySelectorAll('[data-nz-toggle-report]').forEach(function (head) {
		head.addEventListener('click', function () {
			var body = head.nextElementSibling;
			if (!body) {
				return;
			}
			var isHidden = body.hasAttribute('hidden');
			if (isHidden) {
				body.removeAttribute('hidden');
			} else {
				body.setAttribute('hidden', '');
			}
		});
	});

	// Botão "Imprimir / PDF" (viewer de relatório)
	document.querySelectorAll('[data-nz-print]').forEach(function (btn) {
		btn.addEventListener('click', function () {
			window.print();
		});
	});

	// Antes de imprimir, avisa bibliotecas de gráfico responsivas (Chart.js,
	// ApexCharts, ECharts, etc.) para se redesenharem no tamanho da folha —
	// sem isso é comum o gráfico sair em branco ou cortado no PDF.
	window.addEventListener('beforeprint', function () {
		window.dispatchEvent(new Event('resize'));
	});

	// Busca de relatórios na Área do Cliente (filtra por nome/data no cliente).
	(function () {
		var input = document.querySelector('[data-nz-report-search]');
		var scope = document.querySelector('[data-nz-report-scope]');
		if (!input || !scope) {
			return;
		}

		var items = Array.prototype.slice.call(scope.querySelectorAll('[data-nz-report-item]'));
		var groups = Array.prototype.slice.call(scope.querySelectorAll('[data-nz-report-group]'));
		var emptyMsg = document.querySelector('[data-nz-report-empty]');

		function normalize(str) {
			return (str || '').toString().toLowerCase()
				.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
		}

		function filter() {
			var query = normalize(input.value.trim());
			var anyVisible = false;

			items.forEach(function (item) {
				var haystack = normalize(item.getAttribute('data-nz-report-search-text'));
				var match = !query || haystack.indexOf(query) !== -1;
				item.hidden = !match;
				if (match) {
					anyVisible = true;
				}
			});

			// Esconde categorias/subcategorias que ficaram sem nenhum relatório visível.
			groups.forEach(function (group) {
				var hasVisible = group.querySelector('[data-nz-report-item]:not([hidden])');
				group.hidden = !hasVisible;
			});

			if (emptyMsg) {
				emptyMsg.hidden = anyVisible;
			}
		}

		input.addEventListener('input', filter);
	})();

	// Lightbox das galerias do blog: clica na imagem, abre em tela cheia e navega
	(function () {
		var content = document.querySelector('.nz-single-post__content');
		if (!content) {
			return;
		}

		var images = Array.prototype.slice.call(
			content.querySelectorAll('.wp-block-gallery img, .gallery img')
		);
		if (!images.length) {
			return;
		}

		// Descobre a maior versão disponível de cada imagem (link para o arquivo,
		// srcset ou src) e a legenda (figcaption/legenda da galeria ou alt).
		var slides = images.map(function (img) {
			var full = img.getAttribute('src');
			var link = img.closest('a');
			if (link && /\.(jpe?g|png|gif|webp|avif)(\?|$)/i.test(link.getAttribute('href') || '')) {
				full = link.getAttribute('href');
			} else if (img.getAttribute('data-full-url')) {
				full = img.getAttribute('data-full-url');
			} else if (img.currentSrc) {
				full = img.currentSrc;
			}

			var caption = '';
			var figure = img.closest('figure');
			if (figure) {
				var cap = figure.querySelector('figcaption');
				if (cap) {
					caption = cap.textContent.trim();
				}
			}
			if (!caption) {
				var item = img.closest('.gallery-item');
				if (item) {
					var gcap = item.querySelector('.gallery-caption');
					if (gcap) {
						caption = gcap.textContent.trim();
					}
				}
			}
			if (!caption) {
				caption = img.getAttribute('alt') || '';
			}
			return { src: full, caption: caption };
		});

		// Monta a estrutura do lightbox uma única vez.
		var box = document.createElement('div');
		box.className = 'nz-lightbox';
		box.setAttribute('role', 'dialog');
		box.setAttribute('aria-modal', 'true');
		box.setAttribute('aria-hidden', 'true');
		box.innerHTML =
			'<button class="nz-lightbox__close" type="button" aria-label="Fechar">×</button>' +
			'<button class="nz-lightbox__nav nz-lightbox__nav--prev" type="button" aria-label="Anterior">‹</button>' +
			'<figure class="nz-lightbox__figure">' +
				'<img class="nz-lightbox__img" src="" alt="">' +
				'<figcaption class="nz-lightbox__caption"></figcaption>' +
				'<span class="nz-lightbox__count"></span>' +
			'</figure>' +
			'<button class="nz-lightbox__nav nz-lightbox__nav--next" type="button" aria-label="Próxima">›</button>';
		document.body.appendChild(box);

		var imgEl = box.querySelector('.nz-lightbox__img');
		var capEl = box.querySelector('.nz-lightbox__caption');
		var countEl = box.querySelector('.nz-lightbox__count');
		var prevBtn = box.querySelector('.nz-lightbox__nav--prev');
		var nextBtn = box.querySelector('.nz-lightbox__nav--next');
		var closeBtn = box.querySelector('.nz-lightbox__close');
		var current = 0;
		var multiple = slides.length > 1;

		prevBtn.hidden = !multiple;
		nextBtn.hidden = !multiple;

		function render() {
			var slide = slides[current];
			imgEl.setAttribute('src', slide.src);
			imgEl.setAttribute('alt', slide.caption);
			capEl.textContent = slide.caption;
			capEl.style.display = slide.caption ? '' : 'none';
			countEl.textContent = multiple ? (current + 1) + ' / ' + slides.length : '';
		}

		function open(index) {
			current = index;
			render();
			box.classList.add('is-open');
			box.setAttribute('aria-hidden', 'false');
			document.body.classList.add('nz-lightbox-open');
		}

		function close() {
			box.classList.remove('is-open');
			box.setAttribute('aria-hidden', 'true');
			document.body.classList.remove('nz-lightbox-open');
		}

		function go(step) {
			current = (current + step + slides.length) % slides.length;
			render();
		}

		images.forEach(function (img, i) {
			var trigger = img.closest('a') || img;
			trigger.addEventListener('click', function (e) {
				e.preventDefault();
				open(i);
			});
		});

		prevBtn.addEventListener('click', function () { go(-1); });
		nextBtn.addEventListener('click', function () { go(1); });
		closeBtn.addEventListener('click', close);
		box.addEventListener('click', function (e) {
			if (e.target === box || e.target.classList.contains('nz-lightbox__figure')) {
				close();
			}
		});
		document.addEventListener('keydown', function (e) {
			if (!box.classList.contains('is-open')) {
				return;
			}
			if (e.key === 'Escape') {
				close();
			} else if (multiple && e.key === 'ArrowLeft') {
				go(-1);
			} else if (multiple && e.key === 'ArrowRight') {
				go(1);
			}
		});
	})();
	// Ferramentas WebMCP: permitem que agentes de IA no navegador consultem
	// informações da Nozes, busquem conteúdos e gerem o link de WhatsApp.
	// Só roda em navegadores com suporte (navigator.modelContext).
	(function () {
		var mc = navigator.modelContext;
		var info = window.nozesAgent;
		if (!mc || typeof mc.registerTool !== 'function' || !info) {
			return;
		}

		function text(value) {
			return { content: [{ type: 'text', text: typeof value === 'string' ? value : JSON.stringify(value, null, 2) }] };
		}

		var tools = [
			{
				name: 'nozes_informacoes',
				description: 'Retorna quem é a Nozes Estratégia de Marca, o que ela faz e como entrar em contato (telefone, WhatsApp, e-mail, cidade e páginas institucionais).',
				inputSchema: { type: 'object', properties: {} },
				annotations: { readOnlyHint: true },
				execute: function () {
					return text({
						nome: info.name,
						resumo: info.summary,
						telefone: info.phone,
						whatsapp: 'https://wa.me/' + info.whatsapp,
						email: info.email,
						endereco: info.address,
						site: info.siteUrl,
						blog: info.blogUrl,
						paginas: info.pages
					});
				}
			},
			{
				name: 'nozes_buscar_conteudo',
				description: 'Busca artigos do blog e páginas do site da Nozes sobre gestão e estratégia de marca. Retorna título e link de cada resultado.',
				inputSchema: {
					type: 'object',
					properties: {
						termo: { type: 'string', description: 'Palavra ou assunto a buscar, por exemplo "naming" ou "gestão de marca".' }
					},
					required: ['termo']
				},
				annotations: { readOnlyHint: true },
				execute: function (input) {
					var termo = input && input.termo ? String(input.termo) : '';
					var url = info.searchApi + (info.searchApi.indexOf('?') > -1 ? '&' : '?') + 'per_page=8&search=' + encodeURIComponent(termo);
					return fetch(url, { headers: { Accept: 'application/json' } })
						.then(function (r) { return r.json(); })
						.then(function (items) {
							if (!Array.isArray(items) || !items.length) {
								return text('Nenhum conteúdo encontrado para "' + termo + '". O blog completo está em ' + info.blogUrl);
							}
							return text(items.map(function (item) {
								return { titulo: item.title, link: item.url, tipo: item.subtype };
							}));
						})
						.catch(function () {
							return text('Não foi possível buscar agora. O blog completo está em ' + info.blogUrl);
						});
				}
			},
			{
				name: 'nozes_contato_whatsapp',
				description: 'Gera o link para conversar com a Nozes pelo WhatsApp, com uma mensagem inicial opcional. Não envia nada: a pessoa decide se abre o link.',
				inputSchema: {
					type: 'object',
					properties: {
						mensagem: { type: 'string', description: 'Mensagem inicial sugerida, por exemplo o assunto que a pessoa quer conversar.' }
					}
				},
				annotations: { readOnlyHint: true },
				execute: function (input) {
					var link = 'https://wa.me/' + info.whatsapp;
					if (input && input.mensagem) {
						link += '?text=' + encodeURIComponent(String(input.mensagem));
					}
					return text({ whatsapp: link, email: info.email });
				}
			}
		];

		tools.forEach(function (tool) {
			try {
				mc.registerTool(tool);
			} catch (e) {
				// Ferramenta já registrada ou API diferente: ignora sem quebrar o site.
			}
		});
	})();
})();
