# Guia de Uso — Tema Nozes

Este guia explica, em português simples, como instalar e usar o tema no seu WordPress da Hostinger. Não é preciso saber programação para nenhum destes passos.

## 1. Instalar o tema na Hostinger

1. Baixe o arquivo `nozes.zip` (está na raiz deste repositório, gerado a partir da pasta `nozes/`).
2. No seu WordPress, vá em **Aparência → Temas → Adicionar novo → Enviar tema**.
3. Selecione o `nozes.zip` e clique em **Instalar agora** e depois em **Ativar**.
4. Ao ativar, o tema já cria sozinho as páginas iniciais (Início, Sobre, Serviços, Contato, Área do Cliente), um menu principal e define a página inicial — isso só acontece na primeira ativação, então é seguro reativar depois sem duplicar nada.

## 2. O que revisar logo depois de ativar

O tema usa textos de exemplo com a voz da Nozes, mas **alguns trechos estão marcados como "AJUSTE"** porque não conseguimos acessar automaticamente o conteúdo do site atual (somosnozes.com.br) para migrar — o servidor bloqueou o acesso automático. Revise principalmente:

- Página **Serviços** e a seção de serviços da **Início**: confirme os nomes/descrições dos serviços existentes (deixamos 2-3 como placeholder).
- Página **Sobre**: texto de apresentação da empresa/fundadora.
- Depoimentos na Início: são só exemplos, troque por depoimentos reais.

O novo serviço **"Assessoria em Decisões de Negócio e Valorização de Marca"** já está com o texto definitivo, incluindo o destaque visual de "novo" e a FAQ deixando claro que o plano de ações imediatas não está incluso.

## 3. Configurar o essencial (sem precisar de código)

Vá em **Aparência → Personalizar → Configurações da Nozes**:

- **WhatsApp**: número (formato `554830507538`, com código do país) e a mensagem inicial. Confirme que este é o número realmente cadastrado no WhatsApp/WhatsApp Business.
- **Contato e Endereço**: telefone de exibição, e-mail, cidade — usados no rodapé e nos dados estruturados de SEO.
- **Redes Sociais**: Instagram e LinkedIn.
- **SEO e Dados Estruturados**: o resumo da empresa (usado também no arquivo `/llms.txt`, explicado abaixo).

Em **Aparência → Logotipo do Site** você troca a logo pelo arquivo oficial quando quiser (já vai um placeholder com a marca enviada).

### E-mails automáticos (login de cliente, redefinição de senha, novo usuário)

Por padrão, o WordPress envia esses e-mails como remetente genérico "WordPress". O tema já muda isso para aparecer como **remetente "Nozes"**, usando o e-mail que você configurar no campo **"E-mail de contato"** (Personalizar → Contato e Endereço) — tanto o cadastro de um cliente novo quanto os e-mails de redefinição de senha usam esse mesmo endereço.

Duas coisas importantes:

1. Use ali um e-mail real que existe no seu domínio (ex: `contato@somosnozes.com.br`), não um e-mail genérico — isso evita que a mensagem seja rejeitada ou marcada como spam.
2. Trocar só o "remetente" ajuda, mas a forma mais confiável de garantir que os e-mails cheguem (e não caiam em spam) é instalar um plugin de SMTP gratuito, como o **WP Mail SMTP**, e configurá-lo com uma conta de e-mail do seu domínio na Hostinger (a própria Hostinger tem um guia de "SMTP" no painel de e-mails). Isso autentica o envio (SPF/DKIM) em vez de depender do envio padrão do servidor.

## 4. Editando o conteúdo no dia a dia

Você escolheu o **Elementor** como editor visual. Fluxo recomendado:

1. Instale o plugin gratuito **Elementor** (Plugins → Adicionar novo → buscar "Elementor").
2. Abra a página que quer editar e clique em **Editar com Elementor**.
3. Na primeira vez, defina as **Cores e Fontes Globais** do Elementor com a paleta oficial (veja tabela abaixo) e a fonte **Poppins** — assim qualquer coisa nova que você montar no Elementor já nasce no padrão visual da marca.
4. O cabeçalho (menu) e o rodapé são fixos no código do tema (para manter consistência e não quebrar o botão de WhatsApp/links), então o Elementor edita apenas o conteúdo de cada página — igual a maioria dos sites profissionais.

Se preferir não usar Elementor num dia a dia mais simples, o **editor nativo do WordPress** (blocos) também funciona normalmente em qualquer página.

### Paleta oficial (para configurar no Elementor)

| Uso | Cor | Hex |
|---|---|---|
| Base | Preto | `#1D1D1F` |
| Acento primário | Rosa | `#FF0066` |
| Acento primário | Verde limão | `#ABF705` |
| Acento primário | Amarelo limão | `#D8FF01` |
| Acento secundário | Azul | `#1FBDC6` |
| Acento secundário | Amarelo | `#FFD100` |
| Acento terciário | Coral | `#FF6B6B` |
| Acento terciário | Roxo | `#7B4FE0` |

Fonte: **Poppins** (já vem instalada localmente no tema, pesos 400/500/600/700/800).

## 5. Subir uma página pronta feita aqui pelo Claude

Sempre que eu montar uma página especial para você (uma landing page de campanha, por exemplo), o processo é:

1. Crie uma página nova em **Páginas → Adicionar nova**.
2. No painel direito, em **Atributos da página → Modelo**, escolha um dos dois modelos abaixo.
3. Troque o editor de blocos para o modo **Código** (os três pontinhos no canto superior direito → "Editor de código") ou adicione um bloco **HTML personalizado**.
4. Cole o HTML que eu te enviar e publique.

### Qual modelo escolher?

Existem **dois** modelos para páginas prontas — a diferença é se você quer manter ou não o menu e o rodapé do site:

| Modelo | Quando usar | Cabeçalho/Rodapé do tema |
|---|---|---|
| **Página HTML Livre** | O HTML é só o "miolo" da página e você quer manter o menu e o rodapé da Nozes em volta. | Sim (menu + rodapé + botão de WhatsApp) |
| **Página em Branco (HTML completo)** | O HTML já traz o próprio topo, rodapé, estilos — uma página completa e independente. Ocupa a tela inteira. | Não (nada do tema aparece) |

Resumindo: se eu te mandar um **HTML completo** (que já tem cabeçalho e rodapé próprios), use **"Página em Branco (HTML completo)"**. Se for só um bloco de conteúdo para encaixar no site, use **"Página HTML Livre"**.

## 6. Área do Cliente (relatórios mensais)

Cada cliente tem **login individual** e só vê os próprios relatórios.

### Criar um cliente novo

1. **Usuários → Adicionar novo**.
2. Preencha nome/e-mail, e em **Função** escolha **"Cliente"**.
3. Defina uma senha e envie usuário+senha para o cliente (por e-mail ou WhatsApp).
4. O cliente acessa pela página **Área do Cliente** (já está no menu e no rodapé do site).

### Publicar um relatório mensal

1. No menu lateral do admin, vá em **Relatórios (Clientes) → Adicionar novo**.
2. Dê um título (ex: "Relatório — Julho 2026").
3. Troque o editor para o modo **Código** e cole o HTML do relatório.
4. No painel direito, na caixa **"Cliente dono deste relatório"**, selecione o cliente.
5. (Opcional) Na caixa **"Categorias de relatório"**, marque a categoria/subcategoria (veja abaixo).
6. Publique. Ele aparece automaticamente na Área do Cliente daquele usuário, mais recente primeiro — e nenhum outro cliente consegue ver, porque não existe um link público para o relatório: tudo é listado só depois do login.

### Organizar em categorias e subcategorias

Para facilitar quando o cliente tem muitos relatórios, dá para agrupá-los:

1. Vá em **Relatórios (Clientes) → Categorias**.
2. Crie as categorias (ex.: "2026") e, se quiser, subcategorias escolhendo uma **Categoria mãe** (ex.: "1º semestre").
3. Ao criar/editar um relatório, marque a categoria/subcategoria dele.

Na Área do Cliente os relatórios aparecem **agrupados por categoria e subcategoria**. Relatórios sem categoria ficam em "Outros relatórios". O cliente também tem um **campo de busca** para encontrar um relatório pelo nome ou pela data.

### Manter o cliente conectado

Na tela de login há a opção **"Manter conectado neste dispositivo"** (já vem marcada). Com ela, o cliente continua logado por até 30 dias — inclusive se sair para navegar pelo blog/site e voltar depois. A Área do Cliente também é servida sem cache para evitar cair na tela de login por engano.

## 7. SEO e GEO (otimização para buscadores e para IA)

O tema já vem com, sem precisar instalar nada:

- Título, meta descrição, Open Graph e Twitter Card em todas as páginas.
- Dados estruturados (JSON-LD) de **Organização/Negócio Local**, **Artigo** (posts do blog) e **Trilha de navegação (breadcrumbs)**.
- Um shortcode de **FAQ** (`[nozes_faq]`) que gera automaticamente o schema de perguntas e respostas — use-o em qualquer página pelo bloco "Shortcode" ou pelo widget de Shortcode do Elementor.
- Um arquivo `/llms.txt` (ex: `somosnozes.com.br/llms.txt`) com um resumo da empresa, contato e páginas principais — pensado para ferramentas de IA (ChatGPT, Perplexity, etc.) entenderem rapidamente quem é a Nozes.

**Se você instalar um plugin de SEO** (recomendamos o **Rank Math**, gratuito) para ter sitemap, redirecionamentos e mais controle fino de SEO:

- O tema detecta automaticamente o Rank Math/Yoast e para de gerar título/meta description por conta própria, para não conflitar.
- Se ativar os "dados estruturados" (schema) dentro do próprio Rank Math, marque a opção **"Desativar dados estruturados do tema"** em Personalizar → SEO, para não duplicar informações para o Google.

## 8. Site em inglês, sem plugin (só páginas fixas)

O tema tem um jeito nativo de manter uma versão em inglês das páginas fixas (Início, Sobre, Serviços, Contato), sem precisar de nenhum plugin de tradução. O Blog e a Área do Cliente ficam de fora — continuam só em português.

Como usar:

1. Crie a página em inglês normalmente (**Páginas → Adicionar nova**), com o conteúdo já traduzido — por exemplo "Home", "About", "Services" ou "Contact".
2. No painel direito da edição, na caixa **"Idioma da página"**, marque **"English (en-US)"**.
3. Logo abaixo, em **"Página correspondente no outro idioma"**, selecione a página em português equivalente (ex.: a página em inglês "About" aponta para "Sobre"). Ao salvar, o vínculo é feito nos dois sentidos sozinho — não precisa repetir o processo na página em português.
4. Publique.

A partir daí, o tema cuida do resto automaticamente:

- Aparece um botão **PT/EN** no cabeçalho para trocar de idioma, só nas páginas que já têm a correspondente vinculada.
- O menu do site troca os links e os títulos para a versão em inglês quando o visitante está numa página em inglês.

### Menu próprio para a versão em inglês

Por padrão o tema reaproveita o menu em português e troca cada item pela página em inglês correspondente. Itens que não são página (links personalizados, o Blog, submenus) continuam como estão.

Se quiser controle total do menu em inglês (por exemplo, tirar o Blog e renomear "O que fazemos" para "What we do"), monte um menu separado:

1. Vá em **Aparência → Menus → Criar novo menu**, dê o nome que quiser (ex.: "Main Menu EN").
2. Adicione os itens apontando para as páginas em inglês e escreva os rótulos em inglês no campo **"Rótulo de navegação"** de cada item.
3. Em **Configurações do menu**, marque o local **"Menu Principal (Inglês)"**. Existe também **"Menu do Rodapé (Inglês)"** para o rodapé.

Nas páginas marcadas como inglês o tema passa a usar esse menu. Enquanto nenhum menu estiver atribuído a esse local, ele continua traduzindo o menu em português automaticamente.
- Textos fixos do tema (menu, rodapé, botão de WhatsApp, trilha de navegação, página de erro 404) aparecem automaticamente em inglês nessas páginas.
- O Google recebe os sinais corretos de idioma (tag `hreflang` e `og:locale`), para não tratar a versão em inglês como conteúdo duplicado.

Repita o processo para cada página fixa que quiser em inglês. Como não há tradução automática embutida, o texto em si (o que vai dentro da página) precisa ser escrito ou colado por você — o ideal é revisar com alguém fluente antes de publicar, já que o site vai ser visto por empresas americanas.

## 9. Plugins recomendados (gratuitos)

- **Elementor** — editor visual das páginas.
- **Rank Math** ou **Yoast SEO** — sitemap.xml, redirecionamentos, painel de SEO por página.
- **WPForms Lite** (ou similar) — caso queira um formulário de contato além do WhatsApp.
- Um plugin de cache (ex: **WP Super Cache** ou o cache nativo da Hostinger) — a Hostinger já otimiza boa parte disso no servidor.

## 10. Resumo do que foi construído

- Tema WordPress completo e independente (não depende de nenhum outro tema).
- Compatível com Elementor e com o editor nativo do WordPress ao mesmo tempo.
- Paleta e tipografia oficiais da Nozes aplicadas em todo o site.
- Botão de WhatsApp fixo (flutuante) em todas as páginas + botão no menu.
- Novo serviço "Assessoria em Decisões de Negócio e Valorização de Marca" já estruturado e em destaque.
- Área do Cliente com login individual e relatórios em HTML por cliente.
- Modelo de "Página HTML Livre" para publicar páginas prontas feitas por aqui.
- SEO técnico + dados estruturados + FAQ com schema + `/llms.txt` para otimização em buscadores de IA (GEO).
- Páginas fixas em inglês sem plugin, com seletor de idioma, menu e textos do tema traduzidos automaticamente.
